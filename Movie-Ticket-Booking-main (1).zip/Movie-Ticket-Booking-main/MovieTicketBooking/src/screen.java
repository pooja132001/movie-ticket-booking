
interface screen1{
	int num=1;
	int capacity = 100;
}

interface screen2{
	int num=2;
	int capacity = 150;
}

interface screen3{
	int num=3;
	int capacity = 200;
}