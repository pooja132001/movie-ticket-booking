
abstract public class movie {
	String title;
	String genere;
	String duration;
	String director;
}
